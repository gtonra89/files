import java.util.ArrayList;
import javax.faces.bean.ManagedBean;

@ManagedBean

public class Controller {
	
	private ArrayList<Model> models;
	private ArrayList<Manufacturer> manufacturers;
	private ArrayList<Vehicle> Vehicles;
	
	private DAO dao;

	public Controller() {
		try {
			dao = new DAO();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void loadModels() throws Exception {
		setModels(dao.getModelDetails());
	}
	public void loadManufacturers() throws Exception {
		setManufacturers(dao.getManufacturerDetails());
	}
	public void loadVehicles() throws Exception {
		setVehicles(dao.getVehicleDetails());
	}

	public ArrayList<Manufacturer> getManufacturers() {
		return manufacturers;
	}

	public void setManufacturers(ArrayList<Manufacturer> manufacturers) {
		this.manufacturers = manufacturers;
	}

	public ArrayList<Vehicle> getVehicles() {
		return Vehicles;
	}

	public void setVehicles(ArrayList<Vehicle> vehicles) {
		Vehicles = vehicles;
	}

	public ArrayList<Model> getModels() {
		return models;
	}

	public void setModels(ArrayList<Model> models) {
		this.models = models;
	}
}
