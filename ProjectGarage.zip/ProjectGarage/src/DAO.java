	import java.util.ArrayList;
	import javax.naming.Context;
	import javax.naming.InitialContext;
	import javax.sql.DataSource;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;

	public class DAO {

		private DataSource mysqlDS;
		
		public DAO()throws Exception{
			Context context = new InitialContext();
			String jndiName = "java:comp/env/jdbc/garage";
			mysqlDS = (DataSource) context.lookup(jndiName);
		}
		//========================================================================================
		public ArrayList<Manufacturer> getManufacturerDetails() throws Exception{
			ArrayList<Manufacturer> manufacturers = new ArrayList<Manufacturer>();
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("select * from manufacturer");
			ResultSet myResult = myStmt.executeQuery();
			//========================================================================================	
			while(myResult.next()){
				String manu_code = myResult.getString("manu_code");
				String manu_name = myResult.getString("manu_name");
				String manu_details = myResult.getString("manu_details");
				manufacturers.add(new Manufacturer(manu_code, manu_name, manu_details));
			}
			return manufacturers;
		}
		
		/*
		 * get all manufacturer details
		 */
		public ArrayList<Model> getModelDetails() throws Exception{
			ArrayList<Model> models = new ArrayList<Model>();
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("select * " + "from model");
			ResultSet myResult = myStmt.executeQuery();
			//========================================================================================	
			while(myResult.next()){
				
				String manu_code = myResult.getString("manu_code");
				String model_code = myResult.getString("model_code");
				String model_name = myResult.getString("model_name");
				String model_desc = myResult.getString("model_desc");
				models.add(new Model(manu_code, model_code, model_name, model_desc));
			}
			return models;
		}
		
		/*
		 * get all vehicle details
		 */
		public ArrayList<Vehicle> getVehicleDetails() throws Exception{
			ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("select * " + "from vehicle");
			ResultSet myResult = myStmt.executeQuery();
			//========================================================================================	
			while(myResult.next()){
				String reg = myResult.getString("reg");
				String manu_code = myResult.getString("manu_code"); 
				String model_code = myResult.getString("model_code");
				int mileage = myResult.getInt("mileage");
				double price = myResult.getDouble("price");
				String colour = myResult.getString("colour");
				String fuel = myResult.getString("fuel");
				vehicles.add(new Vehicle(reg, manu_code, model_code, mileage, price, colour, fuel));
			}
			return vehicles;
		}
		
		
}
