import javax.faces.bean.ManagedBean;
		
		@ManagedBean

public class Model {

	private String manu_Code;
	private String model_Code;
	private String model_Name;
	private String model_Desc;
	
	
	
	
	public Model(String manu_code2, String model_code2, String model_name2, String model_desc2) {
		this.manu_Code = manu_code2;
		this.model_Code = model_code2;
		this.model_Name	= model_name2;	
		this.model_Desc = model_desc2;
		
	}
	public String getManu_Code() {
		return manu_Code;
	}
	public void setManu_Code(String manu_Code) {
		this.manu_Code = manu_Code;
	}
	public String getModel_Code() {
		return model_Code;
	}
	public void setModel_Code(String model_Code) {
		this.model_Code = model_Code;
	}
	public String getModel_Name() {
		return model_Name;
	}
	public void setModel_Name(String model_Name) {
		this.model_Name = model_Name;
	}
	public String getModel_Desc() {
		return model_Desc;
	}
	public void setModel_Desc(String model_Desc) {
		this.model_Desc = model_Desc;
	}
	
	
}
